#!/usr/bin/env bash

echo "Install Firefox"
yum -y install firefox-45.7.0-2.el7.centos && yum clean all